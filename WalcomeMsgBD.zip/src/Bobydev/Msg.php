<?php

namespace Bobydev;

use onebone\economyapi\EconomyAPI;
use jojoe77777\FormAPI\SimpleForm;
use jojoe77777\FormAPI\CustomForm;
use pocketmine\event\player\PlayerQuitEvent;
use pocketmine\player\Player;
use pocketmine\plugin\PluginBase;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerJoinEvent;
use pocketmine\utils\Config;
use pocketmine\scheduler\ClosureTask;
use pocketmine\Server;

class Msg extends PluginBase implements Listener {
  
  public function onEnable() : void {
        $this->getLogger()->info("JoinMSG-BD By Bobydev Is Now Enabled ✅");
        $this->getServer()->getPluginManager()->registerEvents($this, $this);
  }
  
  public function onJoin(PlayerJoinEvent $event){
    $player = $event->getPlayer();
    $name = $player->getName();
    $player->sendMessage("§l§6====================================\n\n§eHello, §d$name\n\n§aWelcome To BD Skyblock Server\n§aThis Is A Minigame Server There\n§aYou Need Grind And Become Most\n§aPowerful And Richest Person Of This Server.\n\n§9Craft Minions And Custom Armors To Get Some Help!\n\n§l§6====================================");
  }
}